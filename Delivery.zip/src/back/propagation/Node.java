package back.propagation;

public class Node {

  private double value;

  public double getValue() {
    return value;
  }

  public void setValue(double value) {
    this.value = value;
  }

}