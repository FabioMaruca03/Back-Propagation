package back.propagation.neuron;

public class H_units extends N_units {

  public H_units(int previous) {
    super(previous);
  }

}